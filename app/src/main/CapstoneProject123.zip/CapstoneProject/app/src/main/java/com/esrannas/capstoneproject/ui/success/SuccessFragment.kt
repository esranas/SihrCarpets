package com.esrannas.capstoneproject.ui.success


import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.esrannas.capstoneproject.R
import com.esrannas.capstoneproject.common.viewBinding
import com.esrannas.capstoneproject.databinding.FragmentSuccessBinding



class SuccessFragment : Fragment(R.layout.fragment_success) {
    private val binding by viewBinding(FragmentSuccessBinding::bind)

    private fun setupAnim() {
        binding.lottieAnimationView.setAnimation(R.raw.payment_successful_animation)
        binding.lottieAnimationView.speed = 0.8f
        binding.lottieAnimationView.playAnimation()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAnim()
    }
}