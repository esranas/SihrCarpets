package com.esrannas.capstoneproject.common

sealed class Resource<out T : Any> {
    //out T ile disariya data tasiyabilecegimizi gosteriyor
    data class Success<out T : Any>(val data: T) : Resource<T>()
    data class Error(val errorMessage: String) : Resource<Nothing>()
    data class Fail(val failMessage: String) : Resource<Nothing>()
    //object constructor bulundurmuyordu yani ()

}
