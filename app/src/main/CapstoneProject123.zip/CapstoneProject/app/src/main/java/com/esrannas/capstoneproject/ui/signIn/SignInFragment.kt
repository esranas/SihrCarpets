package com.esrannas.capstoneproject.ui.signIn

import android.os.Bundle
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.View
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.esrannas.capstoneproject.R
import com.esrannas.capstoneproject.common.viewBinding
import com.esrannas.capstoneproject.databinding.FragmentSignInBinding

import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SignInFragment : Fragment(R.layout.fragment_sign_in) {
    private val binding by viewBinding(FragmentSignInBinding::bind)
//    private val viewModel by viewModels<SignInViewModel>()
    private lateinit var auth: FirebaseAuth

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        auth.currentUser?.let {
            findNavController().navigate(R.id.signInToHome)
        }

        with(binding) {
            btnSignIn.setOnClickListener {
                val email = etEmail.text.toString()
                val password = etPassword.text.toString()
                if (checkFields(email, password)) {
                    signIn(email, password)
                } else {
                    Snackbar.make(it, "Please fill in the blanks", 1000).show()
                }
            }
            signInToSignUp.setOnClickListener {
                findNavController().navigate(R.id.signUpFragment)
            }
        }
    }

    private fun checkFields(email: String, password: String): Boolean {
        return when {
            (email.isNotEmpty() && password.isNotEmpty()) -> true
            else -> false

        }
    }

    private fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).addOnSuccessListener {
            findNavController().navigate(R.id.signInToHome)
        }.addOnFailureListener {
            Snackbar.make(requireView(), it.message.orEmpty(), 1000).show()
        }
    }
}



