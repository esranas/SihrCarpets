package com.esrannas.capstoneproject.ui.success


class SuccessViewModel {

}