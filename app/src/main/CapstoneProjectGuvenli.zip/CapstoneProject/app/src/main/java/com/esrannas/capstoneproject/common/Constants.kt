package com.esrannas.capstoneproject.common

object Constants {
    const val BASE_URL="https://api.canerture.com/ecommerce/"
}