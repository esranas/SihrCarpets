package com.esrannas.capstoneproject.data.model.request

import com.esrannas.capstoneproject.data.model.response.BaseResponse

data class AddToCartRequest(
    val userId:String,
    val productId:Int
)
