package com.esrannas.capstoneproject.data.model.response

data class GetProductDetailResponse(
    val product: Product?,

    ):BaseResponse()
