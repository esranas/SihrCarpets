package com.esrannas.capstoneproject.data.source.remote

//Interface dosyasi
import com.esrannas.capstoneproject.data.model.request.AddToCartRequest
import com.esrannas.capstoneproject.data.model.request.ClearCartRequest
import com.esrannas.capstoneproject.data.model.request.DeleteFromCartRequest
import com.esrannas.capstoneproject.data.model.response.BaseResponse
import com.esrannas.capstoneproject.data.model.response.GetCartProductsResponse
import com.esrannas.capstoneproject.data.model.response.GetCategoriesResponse
import com.esrannas.capstoneproject.data.model.response.GetProductDetailResponse
import com.esrannas.capstoneproject.data.model.response.GetProductsByCategoryResponse
import com.esrannas.capstoneproject.data.model.response.GetProductsResponse
import com.esrannas.capstoneproject.data.model.response.GetSaleProductsResponse
import com.esrannas.capstoneproject.data.model.response.SearchProductResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

//Get icine yazdiklarimiz base url in sonuna yazdigimiz endpointler
interface ProductService {
    @GET("get_products.php")
    suspend fun getProducts(): Response<GetProductsResponse>

    @GET("get_product_detail.php")
    suspend fun getProductDetail(
        @Query("id") id: Int?,
    ): Response<GetProductDetailResponse>

    @GET("get_cart_products.php")
    suspend fun getCartProducts(
        @Query("userId") userId:String
    ):Response<GetCartProductsResponse>

    @GET("get_products_by_category.php")
    suspend fun getProductsByCategory(
        //yani demek istedigimiz ne zaman ki bu fonksiyonu cagiracam o zaman category parametresini bu fonksiyona gonderecem
        @Query("category") category: String,
    ):Response<GetProductsByCategoryResponse>

    @GET("search_product.php")
    suspend fun searchProduct(
        @Query("query") query: String?,
    ):Response<SearchProductResponse>

    @GET("get_sale_products.php")
    suspend fun getSaleProducts():Response<GetSaleProductsResponse>

    @GET("get_categories.php")
    suspend fun getCategories():Response<GetCategoriesResponse>


    @POST("add_to_cart.php")
    suspend fun addToCart(
        @Body addToCartRequest: AddToCartRequest
    ):BaseResponse

    @POST("delete_from_cart.php")
    suspend fun deleteFromCart(
        @Body deleteFromCartRequest: DeleteFromCartRequest
    ):BaseResponse

    @POST("clear_cart.php")
    suspend fun clearCart(
        @Body clearCartRequest:ClearCartRequest
    ):BaseResponse
}

