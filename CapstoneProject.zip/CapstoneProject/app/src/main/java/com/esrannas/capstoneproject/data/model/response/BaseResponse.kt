package com.esrannas.capstoneproject.data.model.response

open class BaseResponse (

    val status:Int?=null,
    val message:String?=null

)