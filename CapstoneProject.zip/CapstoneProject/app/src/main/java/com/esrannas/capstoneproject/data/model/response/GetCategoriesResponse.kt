package com.esrannas.capstoneproject.data.model.response


import com.google.gson.annotations.SerializedName

data class GetCategoriesResponse(

    val categories: List<String>?,

):BaseResponse()