package com.esrannas.capstoneproject.data.model.request

import com.esrannas.capstoneproject.data.model.response.BaseResponse

data class DeleteFromCartRequest(
   val id:Int,
   val userId:String
)
